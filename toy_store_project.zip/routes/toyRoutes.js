const express = require('express');
const Toy = require('../models/ToyModel');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const toys = await Toy.find();
    res.json(toys);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/', async (req, res) => {
  const toy = new Toy(req.body);
  try {
    const newToy = await toy.save();
    res.status(201).json(newToy);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;